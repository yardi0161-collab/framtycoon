# FARM TYCOON — Android + GitHub Build

Plugin tahap 1 untuk **Paper 1.21.8**, Java 21, Maven. Proyek ini dirancang agar source dapat disimpan di GitHub dan JAR dibangun oleh GitHub Actions; pengguna tidak perlu Android Studio, IntelliJ, laptop, atau terminal lokal.

## Fitur tahap 1
- `/is` membuat/memuat world pulau pribadi per UUID dan teleport ke pulau.
- `/is upgrade` membuka GUI upgrade Level 1–5.
- Island border dan platform bertambah saat upgrade.
- Economy internal SQLite: saldo awal, saldo permanen, dan catatan upgrade.
- Spawn sederhana untuk pemain yang baru pertama kali masuk.

## Target build
- Paper API `1.21.8-R0.1-SNAPSHOT`
- Java 21
- Maven
- Output: `target/FarmTycoon.jar`

## Build melalui GitHub Actions dari HP
1. Di Chrome Android, buka GitHub dan buat repository publik atau privat bernama `FarmTycoon`.
2. Ekstrak ZIP proyek di aplikasi Files.
3. Buka repository → **Add file** → **Upload files**. Pilih seluruh isi folder proyek (termasuk `pom.xml`, `src`, `.github`, dan `README.md`) dengan struktur folder tetap terjaga. Jika pemilih file Android tidak mendukung unggah folder, gunakan cara satu-file-archive di bagian berikut.
4. Commit perubahan ke branch `main`.
5. Buka tab **Actions** → workflow **Build FarmTycoon** → pilih **Run workflow** bila belum berjalan otomatis.
6. Buka run terbaru. Jika status hijau **Success**, gulir ke **Artifacts** dan unduh `FarmTycoon-JAR`.
7. Ekstrak artifact unduhan; di dalamnya ada `FarmTycoon.jar`.

### Alternatif Android jika GitHub tidak bisa mengunggah folder
GitHub web di beberapa browser Android tidak mempertahankan struktur folder saat memilih banyak file. Dalam kondisi itu, unggah file satu per satu dengan membuat path yang sama melalui **Add file → Create new file**, atau gunakan GitHub web dalam mode Desktop dan pilih folder proyek jika pemilih file mendukungnya. Jangan hanya mengunggah ZIP source ke repository lalu berharap Actions otomatis membacanya: workflow harus berada di `.github/workflows/build.yml` pada root repository.

## Instalasi di hosting
1. Pastikan server menjalankan **Paper 1.21.8** dan Java 21.
2. Buka panel hosting → File Manager → folder `plugins`.
3. Upload `FarmTycoon.jar` ke folder `plugins`.
4. Restart server dari panel (jangan gunakan plugin reload).
5. Periksa Console. Cari pesan `FarmTycoon tahap 1 aktif.`
6. Di game, coba `/is` lalu `/is upgrade`.

## Command dan permission
- `/is` — teleport ke pulau atau membuatnya jika belum ada.
- `/is upgrade` — membuka GUI upgrade.
- `farmtycoon.is` — default semua pemain.
- `farmtycoon.admin` — default operator (disiapkan untuk fitur admin lanjutan).

## Data dan konfigurasi
Database `plugins/FarmTycoon/farmtycoon.db` dibuat otomatis di server. File konfigurasi berada di `plugins/FarmTycoon/`:
- `config.yml`: spawn, saldo awal, biaya upgrade, border, ukuran platform.
- `islands.yml`: konfigurasi lanjutan island.
- `messages.yml`: pesan plugin.

## Level island default
| Level | Harga upgrade | Border | Radius platform |
|---|---:|---:|---:|
| 1 | Gratis | 32 | 8 |
| 2 | $100.000 | 48 | 12 |
| 3 | $500.000 | 64 | 16 |
| 4 | $1.000.000 | 80 | 20 |
| 5 | $1.500.000 | 96 | 24 |

## Catatan
Tahap ini adalah fondasi Island + Economy. Market, `/sell`, `/price`, scoreboard, BossBar countdown, dan item lore merupakan tahap berikutnya dan belum termasuk dalam JAR tahap 1. Selalu uji di server cadangan sebelum server utama.
